﻿using API.Application;
using API.Data;
using API.Domain;
using Microsoft.EntityFrameworkCore;

namespace API.Infrastructure.Repository
{
    public class UserRepo : IUserPost<User, int>
    {
        private readonly UserPostContext _context;
        public UserRepo(UserPostContext context)
        {
            _context = context;
        }
        public async Task<IEnumerable<User>> GetAll()
        {
            return await _context.Users.ToListAsync();
        }

        public async Task<User> GetById(int id)
        {
          return await _context.Users.FirstOrDefaultAsync(u=>u.UserId==id) ?? throw new Exception("User not found");
        }
    }
}
