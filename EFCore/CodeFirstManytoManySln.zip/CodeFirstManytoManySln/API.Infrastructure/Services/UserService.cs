﻿using API.Application;
using API.Domain;
using API.Infrastructure.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace API.Infrastructure.Services
{
    public class UserService
    {
        private readonly IUserPost<User, int> _userRepo;
        public UserService(IUserPost<User, int> userRepo)
        {
            _userRepo = userRepo;
        }
        public async Task<IEnumerable<User>> GetAllUsers()
        {
            return await _userRepo.GetAll();
        }
        public async Task<User> GetUserById(int id)
        {
            return await _userRepo.GetById(id);
        }
    }
}
