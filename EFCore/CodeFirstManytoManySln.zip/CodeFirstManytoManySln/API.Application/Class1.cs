﻿namespace API.Application
{
    public class Class1
    {

    }
}
